<?php include 'include/header.php' ?>

<h1 class="text-center fw-bolder py-3">This is Home Page</h1>

<?php include 'include/footer.php' ?>